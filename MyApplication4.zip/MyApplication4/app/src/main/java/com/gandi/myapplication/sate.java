package com.gandi.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class sate extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sate);

        ImageView pindahKeSate = findViewById(R.id.place) ;
        pindahKeSate.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.place) {
            Intent intentSate = new Intent(sate.this, rincian.class);
            startActivity(intentSate);
        }
    }
}
