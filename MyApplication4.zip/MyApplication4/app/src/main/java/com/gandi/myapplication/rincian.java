package com.gandi.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class rincian extends AppCompatActivity implements View.OnClickListener {

    private int harga = 0;
    private int hargaSate = 30000;
    private int qty = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rincian);

        Button buttonTambah = findViewById(R.id.button4);
        buttonTambah.setOnClickListener(this);
        Button buttonKurang = findViewById(R.id.button3);
        buttonKurang.setOnClickListener(this);
        Button buttonPesan = findViewById(R.id.sumbitorder);
        buttonPesan.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.button4) {
            harga += hargaSate;
            qty += 1;
            setText(harga);
        } else if(v.getId() == R.id.button3) {
            if(harga > 0) {
                harga -= hargaSate;
                qty -= 1;
                setText(harga);
            }
        } else if (v.getId()== R.id.sumbitorder) {
            Intent intentterimakasih = new Intent(rincian.this, terimakasih.class);
            startActivity(intentterimakasih);
        }
    }



    private void setText(int hargaText) {
        TextView textView = findViewById(R.id.price_textview);
        TextView qtyView = findViewById(R.id.quantity_textview);

        qtyView.setText(""+qty);
        textView.setText("Rp. "+hargaText);
    }
}