package com.gandi.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class IndonesiaFood extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.indonesiafood);

        ImageView pindahKeSate = findViewById(R.id.imagefood2);
        pindahKeSate.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.imagefood2) {
            Intent intentSate = new Intent(IndonesiaFood.this, sate.class);
            startActivity(intentSate);
        }
    }
}